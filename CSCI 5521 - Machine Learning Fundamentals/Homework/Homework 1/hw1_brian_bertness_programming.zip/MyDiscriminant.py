import numpy as np
# some tips
# |S| is the determinant of S in the discriminant functions, try np.linalg.det()
# you can also directly get the inverse of a matrix by np.linalg.inv()


# ------------------------------------- You are going to implement 3 classifiers and corresponding helper functions --------------------
# ------------------------------------- Three classifiers start from here --------------------------------------------------------------
class GaussianDiscriminantBase:
    def __init__(self) -> None:
        pass

    def calculate_metrics(self, ytest, predictions):
        precision = compute_precision(ytest, predictions)
        recall = compute_recall(ytest, predictions)
        return precision, recall

class GaussianDiscriminant_C1(GaussianDiscriminantBase):
    # classifier initialization
    # input:
    #   k: number of classes (2 for this assignment)
    #   d: number of features; feature dimensions (8 for this assignment)
    def __init__(self, k=2, d=8):
        self.m = np.zeros((k,d))  # m1 and m2, store in 2*8 matrices
        self.S = np.zeros((k,d,d))   # S1 and S2, store in 2*(8*8) matrices
        self.p = np.zeros(2)  # p1 and p2, store in dimension 2 vectors

    # compute the parameters for both classes based on the training data
    def fit(self, Xtrain, ytrain):
        # Step 1: Split the data into two parts based on the labels
        Xtrain1, Xtrain2 = splitData(Xtrain, ytrain)

        # Step 2: Compute the parameters for each class
        # m1, S1 for class1
        self.m[0,:] = computeMean(Xtrain1)
        self.S[0] = computeCov( Xtrain1 )
        
        # m2, S2 for class2
        self.m[1,:]  = computeMean(Xtrain2)
        self.S[1] = computeCov( Xtrain2 )

        # priors for both class
        self.p = computePrior(ytrain)




    # predict the labels for test data
    # Input:
    # Xtest: n*d
    # Output:
    # Predictions: n (all entries will be either number 1 or 2 to denote the labels)
    def predict(self, Xtest):
        # placeholders to store the predictions
        # can be ignored, removed or replaced with any following implementations
        predictions = np.zeros(Xtest.shape[0])

        # for indexing predictions in the loop
        i = 0

        # must convert the means to 2d matrices and transpose to a column vector
        #  at that point I can use formula 5.20 in the book
        mean0 = np.zeros((1, 8))
        mean0[0] = self.m[0]
        mean0 = mean0.transpose()
        mean1 = np.zeros((1, 8))
        mean1[0] = self.m[1]
        mean1 = mean1.transpose()

        for x_observation in Xtest:
            # change the vector to a column vector so it will work with the book's formula
            observation = np.zeros( (1, 8) )
            observation[0] = x_observation
            observation = observation.transpose()   # we pass in a column vectors!

            probClassC1 = computeDisc(observation, mean0, self.S[0], self.p[0])
            probClassC2 = computeDisc(observation, mean1, self.S[1], self.p[1])

            if probClassC1[0][0] > probClassC2[0][0]:
                predictions[i] = 1
            else:
                predictions[i] = 2
            i += 1

        return np.array(predictions)




class GaussianDiscriminant_C2(GaussianDiscriminantBase):
    # classifier initialization
    # input:
    #   k: number of classes (2 for this assignment)
    #   d: number of features; feature dimensions (8 for this assignment)
    def __init__(self, k=2, d=8):
        self.m = np.zeros((k,d))  # m1 and m2, store in 2*8 matrices
        self.shared_S =np.zeros((d,d))  # the shared convariance S that will be used for both classes
        self.p = np.zeros(2)  # p1 and p2, store in dimension 2 vectors

    # compute the parameters for both classes based on the training data
    def fit(self, Xtrain, ytrain):
        # Step 1: Split the data into two parts based on the labels
        Xtrain1, Xtrain2 = splitData(Xtrain, ytrain)

        # Step 2: Compute the parameters for each class
        # m1
        self.m[0, :] = computeMean(Xtrain1)

        # m2
        self.m[1, :] = computeMean(Xtrain2)

        # compute the shared covariance
        self.shared_S = computeCov(Xtrain)  # compute the covariance on the whole data set!

        # priors for both class
        self.p = computePrior(ytrain)

        # Fill in your code here !!!!!!!!!!!!!!!!!!!!!!!
        # Step 3: Compute the shared covariance matrix that is used for both class
        # shared_S is computed by finding a covariance matrix of all the data 

    # predict the labels for test data
    # Input:
    # Xtest: n*d
    # Output:
    # Predictions: n (all entries will be either number 1 or 2 to denote the labels)
    def predict(self, Xtest):
        # placeholders to store the predictions
        # can be ignored, removed or replaced with any following implementations
        predictions = np.zeros(Xtest.shape[0])

        # for indexing predictions in the loop
        i = 0

        # must convert the means to 2d matrices and transpose to a column vector
        #  at that point I can use formula 5.20 in the book
        mean0 = np.zeros((1, 8))
        mean0[0] = self.m[0]
        mean0 = mean0.transpose()
        mean1 = np.zeros((1, 8))
        mean1[0] = self.m[1]
        mean1 = mean1.transpose()

        for x_observation in Xtest:
            # change the vector to a column vector so it will work with the book's formula
            observation = np.zeros( (1, 8) )
            observation[0] = x_observation
            observation = observation.transpose()   # we pass in a column vectors!

            probClassC1 = computeDisc(observation, mean0, self.shared_S, self.p[0])
            probClassC2 = computeDisc(observation, mean1, self.shared_S, self.p[1])

            if probClassC1[0][0] > probClassC2[0][0]:
                predictions[i] = 1
            else:
                predictions[i] = 2
            i += 1

        return np.array(predictions)


class GaussianDiscriminant_C3(GaussianDiscriminantBase):
    # classifier initialization
    # input:
    #   k: number of classes (2 for this assignment)
    #   d: number of features; feature dimensions (8 for this assignment)
    def __init__(self, k=2, d=8):
        self.m = np.zeros((k,d))  # m1 and m2, store in 2*8 matrices
        self.shared_S = np.zeros((d,d))  # the shared convariance S that will be used for both classes
        self.p = np.zeros(2)  # p1 and p2, store in dimension 2 vectors

    # compute the parameters for both classes based on the training data
    def fit(self, Xtrain, ytrain):
        # Step 1: Split the data into two parts based on the labels
        Xtrain1, Xtrain2 = splitData(Xtrain, ytrain)

        # Step 2: Compute the parameters for each class
        # m1
        self.m[0, :] = computeMean(Xtrain1)

        # m2
        self.m[1, :] = computeMean(Xtrain2)

        # compute the shared covariance
        self.shared_S = np.diag(np.diag(computeCov(Xtrain)))

        # priors for both class
        self.p = computePrior(ytrain)

    # predict the labels for test data
    # Input:
    # Xtest: n*d
    # Output:
    # Predictions: n (all entries will be either number 1 or 2 to denote the labels)
    def predict(self, Xtest):
        # placeholders to store the predictions
        # can be ignored, removed or replaced with any following implementations
        predictions = np.zeros(Xtest.shape[0])

        # for indexing predictions in the loop
        i = 0

        # must convert the means to 2d matrices and transpose to a column vector
        #  at that point I can use formula 5.20 in the book
        mean0 = np.zeros((1, 8))
        mean0[0] = self.m[0]
        mean0 = mean0.transpose()
        mean1 = np.zeros((1, 8))
        mean1[0] = self.m[1]
        mean1 = mean1.transpose()

        for x_observation in Xtest:
            # change the vector to a column vector so it will work with the book's formula
            observation = np.zeros( (1, 8) )
            observation[0] = x_observation
            observation = observation.transpose()   # we pass in a column vectors!

            probClassC1 = computeDisc(observation, mean0, self.shared_S, self.p[0])
            probClassC2 = computeDisc(observation, mean1, self.shared_S, self.p[1])

            if probClassC1[0][0] > probClassC2[0][0]:
                predictions[i] = 1
            else:
                predictions[i] = 2
            i += 1

        return np.array(predictions)


# ------------------------------------- Helper Functions start from here --------------------------------------------------------------
# Input:
# features: n*d matrix (n is the number of samples, d is the number of dimensions of the feature)
# labels: n vector
# Output:
# features1: n1*d
# features2: n2*d
# n1+n2 = n, n1 is the number of class1, n2 is the number of samples from class 2
def splitData(features, labels):

    # defensive programming: make sure features and labels are of the same size.
    if (np.size(features, 0) != np.size(labels)):
        raise IndexError( "The number of rows of features and labels do not match.")

    # placeholders to store the separated features (feature1, feature2),
    # can be ignored, removed or replaced with any following implementations
    features1 = np.zeros([np.sum(labels == 1),features.shape[1]])  # array[ num of class y=1 values, number of features
    features2 = np.zeros([np.sum(labels == 2),features.shape[1]])  # array[ num of class y=2 values, number of features

    # need to know what index each feature array is at so I can copy from main feature array.
    # I could rely on the fact that the data has all of class 1 first and then all of class 2 but that seems a wonky
    #   and bug-ridden way to program.
    featuresIndex = np.array( [0,0] )

    # separate the features according to the corresponding labels, for example
    # if features = [[1,1],[2,2],[3,3],[4,4]] and labels = [1,1,1,2], the resulting feature1 and feature2 will be
    # feature1 = [[1,1],[2,2],[3,3]], feature2 = [[4,4]]
    for i in range(0, len(labels)):
        if labels[i] == 1:
            features1[ featuresIndex[0] ] = features[i]
            featuresIndex[0] += 1
        elif labels[i] == 2:
            features2[ featuresIndex[1] ] = features[i]
            featuresIndex[1] += 1
        else:
            raise ValueError("Class in data not in {1,2}.")

    return features1, features2


# compute the mean of input features
# input: 
# features: n*d
# output: d
def computeMean(features):

    # placeholders to store the mean for one class
    # can be ignored, removed or replaced with any following implementations
    m = np.zeros(features.shape[1])

    # fill in the code here !!!!!!!!!!!!!!!!!!!!!!!
    # try to explore np.mean() for convenience
    # decided to go a different route so I could practice with routines I will probably use for calculating variance
    #   and covariance

    m = (np.sum(features, axis = 0))

    # the number of columns is features[0] while the number of rows is len(features)
    m = np.divide( m, float( len(features) ) )

    return m



# wrapper function that calls np.cov() and computes the covariance
# input: 
# features: n*d
# output: d*d
def computeCov(features):
    # placeholders to store the covariance matrix for one class
    # can be ignored, removed or replaced with any following implementations
    covMatrix = np.eye(features.shape[1])

    # try to explore np.cov() for convenience
    covMatrix = np.cov(features, rowvar = False)

    return covMatrix


# compute the priors of input features
# input: 
# labels: n*1
# output: 2
def computePrior(labels):
    # placeholders to store the priors for both class
    # can be ignored, removed or replaced with any following implementations
    p = np.array([0.5,0.5])

    # p[0] contains prior for class 1
    # p[1] contains prior for class 2
    p[0] = np.count_nonzero(labels == 1.0) / float( len(labels ) )
    p[1] = np.count_nonzero(labels == 2.0) / float( len(labels ) )

    return p

# compute the discriminant function
# input:
# observation: d * 1
# means: d * 1
# covMatrix: d*d
# prior: scaler
def computeDisc(observation, means, covMatrix, prior):

    return (-.5) * np.log( np.linalg.det( covMatrix ) ) - 0.5 * ( observation.T @ np.linalg.inv(covMatrix ) @ observation - 2 * observation.T @ np.linalg.inv( covMatrix ) @ means +  means.T @ np.linalg.inv( covMatrix) @ means ) + np.log( prior )


# compute the precision
# input:
# ytest: the ground truth labels of the test data, n*1
# predictions: the predicted labels of the test data, n*1
# output:
# precision: a float with size 1
def compute_precision(ytest, predictions):
    precision = 0.0 # a place holder can be neglected

    # precision = countOf[true positive predictions] / countOf[positive predictions]
    # here we assume label==2 is the positive label
    truePositives = 0
    countOfPositives = 0
    for i in range( len (predictions) ):

        if ( predictions[i] == 2 ):
            countOfPositives += 1

            if ( ytest[i] == 2 ):
                truePositives += 1

    precision = truePositives / countOfPositives
    return precision

# compute the recall
# input:
# ytest: the ground truth labels of the test data, n*1
# predictions: the predicted labels of the test data, n*1
# output:
# recall: a float with size 1
def compute_recall(ytest, predictions):
    recall = 0.0 # a place holder can be neglected

    # recall = countOf[true positive predictions] / countOf[positive labels in ytest]
    # here we assume label==2 is the positive label
    truePositives = 0
    positiveLabelsInTest = 0
    for i in range( len (predictions) ):

        if ytest[i] == 2:
            positiveLabelsInTest += 1

            if ( predictions[i] == 2):
                truePositives += 1

    recall = truePositives / positiveLabelsInTest
    return recall 